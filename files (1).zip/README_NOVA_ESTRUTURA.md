# Nova Estrutura da Dashboard - Relatórios na Sidebar

## 📋 Resumo das Mudanças

Esta refatoração reorganiza a dashboard para exibir os relatórios diretamente na árvore de pastas da sidebar, permitindo que o usuário clique em um relatório e veja o painel de execução na área central.

## 🎯 Objetivos Alcançados

1. **Sidebar interativa**: Pastas agora mostram seus relatórios como itens na árvore
2. **Execução rápida**: Clicar em um relatório abre o painel de execução no centro da tela
3. **Navegação intuitiva**: Estrutura de arquivos/pastas familiar aos usuários
4. **Filtros visíveis**: Interface de filtros e execução sempre acessível

## 📁 Arquivos Modificados

### 1. `FolderTree.tsx` (Novo)
**Localização**: `frontend/src/components/features/FolderTree.tsx`

**Principais mudanças**:
- ✨ **Novo componente `RelatorioItem`**: Renderiza relatórios dentro das pastas
- 🔄 **Interface `RelatorioNode`**: Define estrutura mínima do relatório na árvore
- 🎨 **Visual aprimorado**: Ícones de arquivo, hover effects, botão de executar
- 🔗 **Props adicionadas**:
  - `relatorioSelecionado`: ID do relatório atualmente aberto
  - `onSelectRelatorio`: Callback para abrir um relatório
  - `relatorios` em `PastaNode`: Array de relatórios da pasta

**Estrutura visual**:
```
📁 Pasta Vendas (5)          <- Contador de relatórios
  📄 Relatório Mensal        <- Item clicável
  📄 Performance Vendedores
  📁 Subpasta Comissões
    📄 Relatório Comissões
```

### 2. `RelatorioExecutor.tsx` (Novo)
**Localização**: `frontend/src/components/features/RelatorioExecutor.tsx`

**Funcionalidades**:
- 📊 **Painel de execução completo**: Substitui a necessidade de navegar para outra página
- 🎛️ **Renderização de filtros**: Suporta DATA, TEXTO, NUMERO, LISTA
- ▶️ **Execução inline**: Executa e mostra resultados na mesma tela
- 💾 **Export Excel**: Botão para exportar direto da visualização
- ⚡ **Feedback visual**: Loading states, mensagens de erro, tempo de execução
- 📈 **Tabela de resultados**: Mostra até 100 linhas com scroll

**Tipos de filtro suportados**:
```typescript
- DATA: Input date picker
- TEXTO: Input text com placeholder
- NUMERO: Input number
- LISTA: Select dropdown com opções
```

### 3. `Dashboard.tsx` (Modificado)
**Localização**: `frontend/src/pages/Dashboard.tsx`

**Principais mudanças**:
- 📍 **Estado `relatorioSelecionado`**: Controla qual relatório está aberto
- 🔀 **Novo ViewType `'relatorio'`**: Identifica quando está em modo execução
- 🔄 **Função `organizarPastasComRelatorios`**: Popula relatórios nas pastas da árvore
- 🎭 **Renderização condicional**: 
  - Se relatório selecionado → Mostra `RelatorioExecutor`
  - Se não → Mostra lista tradicional de relatórios

**Novos handlers**:
```typescript
handleSelectRelatorio(id)  // Abre relatório no executor
handleFecharRelatorio()    // Fecha executor e volta para lista
```

## 🚀 Como Usar

### Para o Usuário Final

1. **Navegar pelas pastas**:
   - Clique no ícone de pasta para expandir/colapsar
   - Veja o contador de relatórios em cada pasta

2. **Executar um relatório**:
   - Clique no nome do relatório na sidebar
   - Configure os filtros no painel central
   - Clique em "Executar Relatório"
   - Veja os resultados na mesma tela

3. **Exportar resultados**:
   - Após executar, clique em "Exportar Excel"
   - O arquivo será baixado automaticamente

4. **Voltar para lista**:
   - Clique no ícone X no canto superior direito do executor
   - Ou clique em outra pasta/seção na sidebar

### Para Desenvolvedores

#### Integrar os novos componentes:

```typescript
// 1. Importar componentes
import { FolderTree } from '@/components/features/FolderTree'
import { RelatorioExecutor } from '@/components/features/RelatorioExecutor'

// 2. Adicionar estados
const [relatorioSelecionado, setRelatorioSelecionado] = useState<string | null>(null)

// 3. Usar FolderTree com novos props
<FolderTree
  relatorioSelecionado={relatorioSelecionado}
  onSelectRelatorio={handleSelectRelatorio}
  // ... outros props existentes
/>

// 4. Renderização condicional
{relatorioSelecionado ? (
  <RelatorioExecutor
    relatorioId={relatorioSelecionado}
    onClose={handleFecharRelatorio}
  />
) : (
  // Lista de relatórios tradicional
)}
```

#### Estrutura de dados esperada:

```typescript
interface PastaNode {
  id: string
  nome: string
  qtd_relatorios: number
  relatorios?: RelatorioNode[]  // NOVO!
  subpastas?: PastaNode[]
}

interface RelatorioNode {
  id: string
  nome: string
  descricao?: string
}
```

## 🎨 Melhorias Visuais

### Sidebar
- ✅ Largura aumentada de 256px para 288px (w-64 → w-72)
- ✅ Relatórios com indentação extra para hierarquia clara
- ✅ Ícone de documento (FileText) para diferenciar de pastas
- ✅ Botão de play aparece no hover do relatório
- ✅ Highlight quando relatório está selecionado

### Área Central
- ✅ Header com título e descrição do relatório
- ✅ Seção de filtros agrupada em card
- ✅ Grid responsivo para filtros (1, 2 ou 3 colunas)
- ✅ Botões de ação destacados (Executar, Exportar)
- ✅ Tabela de resultados com scroll horizontal
- ✅ Indicadores de performance (tempo, linhas)

## 📊 Fluxo de Dados

```
1. Dashboard carrega pastas e relatórios
   ↓
2. organizarPastasComRelatorios() popula relatorios[] em cada pasta
   ↓
3. FolderTree renderiza árvore com pastas e relatórios
   ↓
4. Usuário clica em relatório
   ↓
5. handleSelectRelatorio() atualiza relatorioSelecionado
   ↓
6. Dashboard renderiza RelatorioExecutor
   ↓
7. RelatorioExecutor carrega detalhes e permite execução
   ↓
8. Usuário clica em X
   ↓
9. handleFecharRelatorio() limpa relatorioSelecionado
   ↓
10. Dashboard volta a mostrar lista de relatórios
```

## 🔧 Endpoints Necessários

Os componentes assumem que os seguintes endpoints estão disponíveis:

```typescript
// Carregar relatório específico
GET /relatorios/:id/
Response: { id, nome, descricao, query, filtros[], conexao_id }

// Executar relatório
POST /relatorios/:id/executar/
Body: { filtros: { parametro: valor } }
Response: { dados: [...], sucesso: true }

// Exportar relatório
POST /relatorios/:id/exportar/
Body: { filtros: {...}, formato: 'xlsx' }
Response: Binary (Excel file)
```

## ⚠️ Considerações Importantes

### Performance
- **Lazy loading**: Relatórios só são mostrados quando a pasta está expandida
- **Limite de visualização**: Apenas 100 linhas renderizadas na tabela
- **Cache**: Dados do relatório são mantidos até fechar o executor

### UX
- **Feedback visual**: Loading spinners, mensagens de sucesso/erro
- **Validação**: Filtros obrigatórios são verificados antes da execução
- **Navegação**: Breadcrumbs mantidos para contexto de localização

### Acessibilidade
- **Teclado**: Todos os controles acessíveis via Tab
- **Semântica**: Uso correto de botões e inputs
- **Feedback**: Toasts para ações importantes

## 📝 Próximos Passos Sugeridos

### Melhorias Futuras
1. **Drag & Drop**: Arrastar relatórios entre pastas
2. **Busca na sidebar**: Filtrar relatórios diretamente na árvore
3. **Favoritos na sidebar**: Seção dedicada com estrela
4. **Histórico de execuções**: Link para ver execuções anteriores
5. **Visualizações**: Gráficos além de tabelas
6. **Salvar filtros**: Templates de filtros favoritos
7. **Compartilhar**: Gerar link com filtros pré-configurados

### Otimizações
1. **Virtual scrolling**: Para muitos relatórios
2. **Pagination**: Para resultados grandes
3. **WebSocket**: Updates em tempo real
4. **Cache inteligente**: Redis para queries frequentes

## 🐛 Troubleshooting

### Relatórios não aparecem nas pastas
- Verifique se `organizarPastasComRelatorios()` está sendo chamada
- Confira se relatórios têm `pasta_id` definido
- Verifique o console para erros de API

### Executor não carrega
- Confirme que o endpoint `/relatorios/:id/` está respondendo
- Verifique se os filtros estão no formato correto
- Veja o console para erros de validação

### Export não funciona
- Certifique-se que o backend está retornando blob
- Verifique configuração de CORS
- Confirme que `responseType: 'blob'` está no request

## 📚 Referências

- [React useState](https://react.dev/reference/react/useState)
- [TypeScript Interfaces](https://www.typescriptlang.org/docs/handbook/interfaces.html)
- [Lucide Icons](https://lucide.dev/)
- [Tailwind CSS](https://tailwindcss.com/)

---

**Desenvolvido com ❤️ para uma melhor experiência do usuário**
